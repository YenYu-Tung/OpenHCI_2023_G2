export default 'test-file-stub';

// For svgr
export const ReactComponent = 'test-file-stub';
