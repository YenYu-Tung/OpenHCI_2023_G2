export default {
	'--standard': '#999',
	'--secondary': '#DDD',
	'--darkBlack': '#404040',
};
