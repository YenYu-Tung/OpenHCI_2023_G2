import React from 'react';

import Navigation from 'components/molecules/Navigation';

import styles from './index.css';

const Header = () => <header className={styles.header}> </header>;

export default Header;
