import React from 'react';

import styles from './index.css';

const Footer = () => <footer className={styles.footer}> </footer>;

export default Footer;
