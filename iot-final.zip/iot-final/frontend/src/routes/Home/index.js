import React, { useEffect, useState } from 'react';
import classnames from 'classnames';
import Div100vh from 'react-div-100vh';
import { hot } from 'react-hot-loader/root';

import styles from './index.css';

const Home = () => {
	const ws = new WebSocket('ws://192.168.0.195:8080/');
	const [on, setOn] = useState(false);

	useEffect(() => {
		window.ws = ws;
		ws.onopen = () => {
			console.log('open connection');
		};

		if (ws) {
			ws.onmessage = event => {
				const data = JSON.parse(event.data);
				setOn(data === 'sosad');

				if (data === 'sosad') {
					// eslint-disable-next-line
					alert('有小偷！！！');
				}
			};
		}
	}, []);

	const onClick = () => {
		window.ws = ws;
		setOn(!on);

		ws.send(
			JSON.stringify({
				status: !on,
			}),
		);
	};

	return (
		<Div100vh style={{ display: 'flex', alignItems: 'center' }}>
			<div className={classnames(styles.wrapper)}>
				<div className={styles['power-switch']}>
					<input type="checkbox" onChange={onClick} checked={on} />
					<div className={styles.button}>
						<svg className={styles['power-off']}>
							<use xlinkHref="#line" className={styles.line} />
							<use xlinkHref="#circle" className={styles.circle} />
						</svg>
						<svg className={styles['power-on']}>
							<use xlinkHref="#line" className={styles.line} />
							<use xlinkHref="#circle" className={styles.circle} />
						</svg>
					</div>
				</div>

				<svg xmlns="http://www.w3.org/2000/svg" style={{ display: 'none' }}>
					<symbol xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 150" id="line">
						<line x1="75" y1="34" x2="75" y2="58" />
					</symbol>
					<symbol xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 150" id="circle">
						<circle cx="75" cy="80" r="35" />
					</symbol>
				</svg>
			</div>
		</Div100vh>
	);
};

export default hot(Home);
