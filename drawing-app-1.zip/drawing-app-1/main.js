let color = "black";
let strokeSize = 7;
let restore_array = [];
let index = -1;
let selectColorGraph = document.getElementById("selectColorGraph")

function changeSize(width)
{
  // console.log(width);
  strokeSize = width;
}

function changeColorAndSize(data) {
  color = data;
  selectColorGraph.value = data;
  $(".strokecolor").css("background",data);
  // No size anymore
  // strokeSize = width;
}
function changecolorbygraph(){
  color = this.value;
  $(".strokecolor").css("background",this.value);
}

var highlightColor = "rgb(189, 189, 189)";

function highlight(stroke){
  $(".strokehighlight").css("background","none");
  $("#stroke" + stroke + "out").css("background", highlightColor);
}


window.addEventListener("load", () => {
  const canvas = document.querySelector("#canvas");
  const ctx = canvas.getContext("2d");

  //resizing
  canvas.height = window.innerHeight;
  canvas.width = window.innerWidth;

  //variables
  let painting = false;
  ctx.fillStyle = 'white';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  //functions
  function startPosition(e) {
    painting = true;
    draw(e);
  }

  function endPosition() {
    painting = false;
    ctx.beginPath();
    cPush();
    if(event.type != 'touchout'){
      restore_array.push(ctx.getImageData(0,0,canvas.width,canvas.height));
      index += 1;
      // console.log(restore_array);
    }
  }

  function draw(e) {
    if (!painting) {
      return;
    }
    
    e.preventDefault();
    ctx.lineWidth = strokeSize;
    ctx.lineCap = "round";
 
    // ctx.lineTo(e.clientX, e.clientY);
    if (e.type == 'touchmove'){
      ctx.lineTo(e.touches[0].clientX, e.touches[0].clientY);
    } else if (e.type == 'mousemove'){
      ctx.lineTo(e.clientX, e.clientY);
    }
      
    ctx.stroke();
    ctx.strokeStyle = color;
    ctx.beginPath();
    
    // ctx.moveTo(e.clientX, e.clientY);
    if (e.type == 'touchmove'){
      ctx.moveTo(e.touches[0].clientX, e.touches[0].clientY);
    } else if (e.type == 'mousemove'){
      ctx.moveTo(e.clientX, e.clientY);
    }
  }
  //event listeners
  canvas.addEventListener("mousedown", startPosition);
  canvas.addEventListener("touchstart", startPosition);
  canvas.addEventListener("mouseup", endPosition);
  canvas.addEventListener("touchend", endPosition);
  canvas.addEventListener("mousemove", draw);
  canvas.addEventListener("touchmove", draw);
  selectColorGraph.addEventListener("input",changecolorbygraph);
});

const canvas = document.querySelector("#canvas");
const ctx = canvas.getContext("2d");


function undo(){
  if(index <= 0){
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    // ctx.fillRect(0, 0, canvas.width, canvas.height);
  } else{
    index -= 1;
    restore_array.pop();
    ctx.putImageData(restore_array[index], 0, 0);
  }
}

let clearBtn = document.querySelector(".clear")
clearBtn.addEventListener("click", () => {
var yes = confirm('確定要刪掉整個畫面嗎？');
if (yes) {
  ctx.clearRect(0, 0, canvas.width, canvas.height)
  let restore_array = [];
  let index = -1;
} else {
}
})

var cPushArray = new Array();
var cStep = -1;

function cPush() {
    cStep++;
    if (cStep < cPushArray.length) { cPushArray.length = cStep; }
    cPushArray.push(document.getElementById('canvas').toDataURL());
    document.title = cStep + ":" + cPushArray.length;
    // console.log(cPushArray);
}
function cUndo() {
    if (cStep > 0) {
        cStep--;
        var canvasPic = new Image();
        canvasPic.src = cPushArray[cStep];
        canvasPic.onload = function () { ctx.drawImage(canvasPic, 0, 0); }
        document.title = cStep + ":" + cPushArray.length;
    }else{
      cStep = -1;
      ctx.fillStyle = 'white';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }

}
function cRedo() {
    if (cStep < cPushArray.length-1) {
        cStep++;
        var canvasPic = new Image();
        canvasPic.src = cPushArray[cStep];
        canvasPic.onload = function () { ctx.drawImage(canvasPic, 0, 0); }
        document.title = cStep + ":" + cPushArray.length;
    }
}















